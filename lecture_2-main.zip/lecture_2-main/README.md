# lecture_2
Cloud Development

Naam: Jahir Estupinan

Studentennummer: 0954098

I included the wait-for-it in the dockerfile of the backend container rather than the docker-compose.yaml file.
